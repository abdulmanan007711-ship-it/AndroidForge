package com.offlinepdftextchanger

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OverlayModelTest {
    @Test fun overlayRetainsUnicodeText() {
        val value = "Hello اردو العربية"
        val overlay = TextOverlay(1L, 0, value)
        assertEquals(value, overlay.text)
        assertTrue(overlay.text.contains("اردو"))
        assertTrue(overlay.text.contains("العربية"))
    }

    @Test fun overlayDefaultsToFirstPageAndNormalizedCoordinates() {
        val overlay = TextOverlay(2L, 0, "test")
        assertEquals(0, overlay.pageIndex)
        assertTrue(overlay.xFraction in 0f..1f)
        assertTrue(overlay.yFraction in 0f..1f)
    }
}
