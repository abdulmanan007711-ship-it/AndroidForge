package com.offlinepdftextchanger

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.max

data class TextOverlay(
    val id: Long,
    val pageIndex: Int,
    val text: String,
    val xFraction: Float = 0.12f,
    val yFraction: Float = 0.18f,
    val fontSize: Float = 24f,
    val color: Int = AndroidColor.BLACK,
    val coverBehind: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { OfflinePdfApp(contentResolver, cacheDir) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OfflinePdfApp(resolver: ContentResolver, cacheDir: File) {
    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageIndex by remember { mutableIntStateOf(0) }
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var pageWidth by remember { mutableIntStateOf(612) }
    var pageHeight by remember { mutableIntStateOf(792) }
    var overlayText by remember { mutableStateOf("") }
    var overlays by remember { mutableStateOf(listOf<TextOverlay>()) }
    var undoStack by remember { mutableStateOf(listOf<List<TextOverlay>>()) }
    var redoStack by remember { mutableStateOf(listOf<List<TextOverlay>>()) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var status by remember { mutableStateOf("Open a PDF stored on this device to begin.") }
    var busy by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var outputName by remember { mutableStateOf("edited-document.pdf") }
    var selectedOverlayId by remember { mutableStateOf<Long?>(null) }
    var searchText by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf("") }

    fun rememberChange(next: List<TextOverlay>) {
        undoStack = undoStack + listOf(overlays)
        redoStack = emptyList()
        overlays = next
    }

    fun loadPage(index: Int) {
        val uri = sourceUri ?: return
        busy = true
        try {
            val file = copyUriToCache(resolver, uri, cacheDir)
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    if (renderer.pageCount > 0) {
                        val safe = index.coerceIn(0, renderer.pageCount - 1)
                        renderer.openPage(safe).use { page ->
                            val width = max(1, page.width * 2)
                            val height = max(1, page.height * 2)
                            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            bitmap.eraseColor(AndroidColor.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            pageBitmap = bitmap
                            pageWidth = page.width
                            pageHeight = page.height
                            pageIndex = safe
                            pageCount = renderer.pageCount
                        }
                    }
                }
            }
            status = "Page ${index + 1} ready. All processing stays on this device."
        } catch (e: Exception) {
            status = "Could not render PDF: ${e.message ?: "unsupported or damaged file"}"
        } finally { busy = false }
    }

    val openPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                resolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            sourceUri = uri
            sourceName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Selected PDF"
            overlays = emptyList()
            undoStack = emptyList()
            redoStack = emptyList()
            pageIndex = 0
            loadPage(0)
        }
    }
    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            busy = true
            try {
                val input = sourceUri ?: throw IOException("Open a PDF first")
                val temp = copyUriToCache(resolver, input, cacheDir)
                val exported = File(cacheDir, "export-${System.currentTimeMillis()}.pdf")
                PDDocument.load(temp).use { doc ->
                    overlays.groupBy { it.pageIndex }.forEach { (pIndex, pageOverlays) ->
                        if (pIndex !in 0 until doc.numberOfPages) return@forEach
                        val page = doc.getPage(pIndex)
                        val pageW = page.mediaBox.width
                        val pageH = page.mediaBox.height
                        // Render text with Android Canvas, then embed as an image. This uses Android's
                        // Unicode text layout (including RTL shaping) without pretending to rewrite
                        // the PDF's original embedded text objects.
                        val scale = 2f
                        val bitmap = Bitmap.createBitmap(max(1, (pageW * scale).toInt()), max(1, (pageH * scale).toInt()), Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(AndroidColor.TRANSPARENT)
                        val canvas = Canvas(bitmap)
                        pageOverlays.forEach { item ->
                            val x = item.xFraction * bitmap.width
                            val y = item.yFraction * bitmap.height
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = item.color
                                textSize = item.fontSize * scale
                                textAlign = Paint.Align.LEFT
                                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
                            }
                            if (item.coverBehind) {
                                val fm = paint.fontMetrics
                                val width = max(140f, paint.measureText(item.text) + 20f)
                                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.WHITE }
                                canvas.drawRect(x - 8f, y + fm.ascent - 5f, x + width, y + fm.descent + 6f, bg)
                            }
                            canvas.drawText(item.text, x, y, paint)
                        }
                        val pdImage = LosslessFactory.createFromImage(doc, bitmap)
                        PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                            stream.drawImage(pdImage, 0f, 0f, pageW, pageH)
                        }
                        bitmap.recycle()
                    }
                    doc.save(exported)
                }
                resolver.openOutputStream(uri, "w")?.use { out -> exported.inputStream().use { it.copyTo(out) } }
                    ?: throw IOException("Could not open the destination")
                exported.delete()
                status = "Saved PDF with ${overlays.size} overlay(s). Original file was preserved."
            } catch (e: Exception) {
                status = "Save failed; original PDF is unchanged. ${e.message ?: ""}"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2457C5), secondary = Color(0xFF2E8B78))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Offline PDF Text Changer", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Private • On-device • No account", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    actions = {
                        IconButton(onClick = { openPicker.launch(arrayOf("application/pdf")) }) {
                            Icon(Icons.Default.FileOpen, contentDescription = "Open PDF")
                        }
                        IconButton(onClick = { if (sourceUri != null) showSaveDialog = true }, enabled = sourceUri != null && !busy) {
                            Icon(Icons.Default.Save, contentDescription = "Save as")
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (sourceUri == null) {
                    Spacer(Modifier.height(30.dp))
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Edit PDFs offline", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("Open a local PDF, add replacement text overlays, then export a new copy. Your source file is never changed by default.")
                            Button(onClick = { openPicker.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.FileOpen, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Choose PDF")
                            }
                        }
                    }
                    FeatureNote("Text overlays", "Add text in English, Urdu, or Arabic. Android text layout handles RTL shaping for overlays.")
                    FeatureNote("Honest editing mode", "This version adds a new layer over the page. It does not rewrite existing embedded PDF text objects.")
                    FeatureNote("Local files only", "No network permission, account, analytics, or cloud upload.")
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(sourceName, maxLines = 1, fontWeight = FontWeight.SemiBold)
                            Text(if (pageCount > 0) "Page ${pageIndex + 1} of $pageCount" else "Loading pages…", fontSize = 12.sp)
                        }
                        IconButton(onClick = { if (pageIndex > 0) loadPage(pageIndex - 1) }, enabled = pageIndex > 0 && !busy) { Icon(Icons.Default.ArrowBack, "Previous page") }
                        IconButton(onClick = { if (pageIndex + 1 < pageCount) loadPage(pageIndex + 1) }, enabled = pageIndex + 1 < pageCount && !busy) { Icon(Icons.Default.ArrowForward, "Next page") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { zoom = (zoom / 1.2f).coerceAtLeast(0.6f) }) { Text("−") }
                        Text("Zoom ${(zoom * 100).toInt()}%", fontSize = 12.sp)
                        OutlinedButton(onClick = { zoom = (zoom * 1.2f).coerceAtMost(2.5f) }) { Text("+") }
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack = redoStack + listOf(overlays)
                                overlays = undoStack.last()
                                undoStack = undoStack.dropLast(1)
                            }
                        }, enabled = undoStack.isNotEmpty()) { Icon(Icons.Default.Undo, "Undo") }
                        IconButton(onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack = undoStack + listOf(overlays)
                                overlays = redoStack.last()
                                redoStack = redoStack.dropLast(1)
                            }
                        }, enabled = redoStack.isNotEmpty()) { Icon(Icons.Default.Redo, "Redo") }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFFE7EAF0)), contentAlignment = Alignment.Center) {
                        val bmp = pageBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "PDF page preview",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 440.dp).padding(4.dp)
                            )
                        } else Text("No page preview")
                        if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
                    }
                    Text("Add overlay text", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = overlayText,
                        onValueChange = { overlayText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Type English, اردو, or العربية") },
                        minLines = 1,
                        maxLines = 3,
                        textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Start)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            if (overlayText.isNotBlank()) {
                                rememberChange(overlays + TextOverlay(
                                    id = System.nanoTime(), pageIndex = pageIndex, text = overlayText,
                                    xFraction = 0.12f, yFraction = 0.22f + (overlays.count { it.pageIndex == pageIndex } % 5) * 0.07f
                                ))
                                status = "Overlay added. Export to apply it to a new PDF."
                                overlayText = ""
                            }
                        }, enabled = overlayText.isNotBlank()) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Add text")
                        }
                        OutlinedButton(onClick = {
                            val selected = selectedOverlayId
                            if (selected != null) rememberChange(overlays.filterNot { it.id == selected })
                            selectedOverlayId = null
                        }, enabled = selectedOverlayId != null) {
                            Icon(Icons.Default.Delete, null); Text("Delete selected")
                        }
                    }
                    if (overlays.any { it.pageIndex == pageIndex }) {
                        Text("Overlays on this page", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        LazyColumn(Modifier.heightIn(max = 100.dp)) {
                            itemsIndexed(overlays.filter { it.pageIndex == pageIndex }) { _, item ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selectedOverlayId == item.id, onClick = { selectedOverlayId = item.id })
                                    Text(item.text, Modifier.weight(1f), maxLines = 1)
                                    TextButton(onClick = {
                                        rememberChange(overlays.map { if (it.id == item.id) it.copy(coverBehind = !it.coverBehind) else it })
                                    }) { Text(if (item.coverBehind) "White cover: on" else "Cover text") }
                                }
                            }
                        }
                    }
                    OutlinedTextField(
                        value = searchText, onValueChange = { searchText = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text("Search extracted PDF text") },
                        trailingIcon = { TextButton(onClick = {
                            searchResults = if (searchText.isBlank()) "Enter a search phrase." else
                                "Search is not implemented in this initial build; no OCR or full-text index is bundled."
                        }) { Text("Search") } }
                    )
                    if (searchResults.isNotBlank()) Text(searchResults, fontSize = 12.sp)
                }
                Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save a new PDF") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This exports a copy and leaves the original unchanged. Existing embedded text is not rewritten.")
                    OutlinedTextField(value = outputName, onValueChange = { outputName = it }, label = { Text("File name") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showSaveDialog = false
                    val name = outputName.trim().ifBlank { "edited-document.pdf" }.let { if (it.endsWith(".pdf", true)) it else "$it.pdf" }
                    savePicker.launch(name)
                }) { Text("Choose save location") }
            },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun FeatureNote(title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun copyUriToCache(resolver: ContentResolver, uri: Uri, cacheDir: File): File {
    val out = File(cacheDir, "opened-${uri.hashCode().toUInt()}.pdf")
    if (out.exists() && out.length() > 0) return out
    resolver.openInputStream(uri).use { input ->
        if (input == null) throw IOException("Could not read selected file")
        FileOutputStream(out).use { output -> input.copyTo(output) }
    }
    if (out.length() == 0L) throw IOException("The selected file is empty")
    return out
}
