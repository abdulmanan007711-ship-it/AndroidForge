#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v java >/dev/null 2>&1; then echo "ERROR: Java/JDK is required." >&2; exit 2; fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle is not installed. Open this project in Android Studio or install Gradle 8.9+." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT to an installed Android SDK." >&2
  exit 2
fi
gradle :app:testDebugUnitTest :app:assembleDebug "$@"
