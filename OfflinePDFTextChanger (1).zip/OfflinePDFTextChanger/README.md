# Offline PDF Text Changer

An original, local-first Android Studio project using Kotlin, Jetpack Compose, Android `PdfRenderer`, and PDFBox-Android.

## Status and scope

This is an **initial source implementation**, not a verified release. The current execution environment had OpenJDK 21 but no Android SDK, Gradle executable, Kotlin compiler, Android emulator, or container runtime, and outbound DNS/network access was unavailable. Therefore no APK has been built or installed here. Use Android Studio or the build script below to build it in an Android-capable environment.

## Implemented in source

- Native Android project, Kotlin and Jetpack Compose UI.
- Local PDF selection through Android Storage Access Framework (`ACTION_OPEN_DOCUMENT` via `OpenDocument`).
- Page rendering and previous/next page navigation using Android `PdfRenderer`.
- Add text overlays and undo/redo of overlay changes.
- Mark an overlay to paint a white rectangle behind its text.
- Export as a new PDF using Android Canvas to rasterize overlay text and PDFBox-Android to append the overlay image to the selected page.
- Android Canvas text rendering is used for overlay glyph shaping and supports Unicode / RTL text according to the Android system's shaping implementation.
- No Internet permission, accounts, analytics, or cloud upload code.
- Export uses a document picker and leaves the original document unchanged by default.

## Important editing limitations

This version **does not edit or remove existing embedded PDF text objects**. The cover option paints a white rectangle on the overlay layer; it may not match colored, patterned, or transparent backgrounds. Text overlays are rasterized into an image per affected page and therefore are not selectable text after export. The app deliberately does not describe this as true embedded-text editing.

Scanned PDFs are rendered normally, but bundled offline OCR is **not included**. No OCR engine/model is downloaded at runtime. Full-text search, page rotation, page-range export, precise overlay dragging/resizing, encrypted PDF handling, and a full recent-files/settings UI remain unimplemented. The search control currently explains this limitation. Treat this as a starting project requiring further development and device testing, not a complete feature-equivalent to commercial PDF editors.

## Build requirements

- Android Studio with Android SDK Platform 35 and Build Tools installed.
- JDK 17 (JDK 21 may also work with the selected Gradle/AGP combination).
- Network access on the build machine for the first Gradle dependency resolution; after dependencies are cached, build offline with Gradle's `--offline` flag.
- Gradle 8.9+ compatible with Android Gradle Plugin 8.7.3.

### Build with Android Studio

1. Extract the ZIP.
2. Open the `OfflinePDFTextChanger` directory in Android Studio.
3. Allow Gradle sync to finish.
4. Run the `app` configuration on an Android 8.0+ device/emulator.

### Build from a shell

On a machine with Gradle installed and Android SDK configured:

```bash
gradle --version
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

The debug APK should be generated at:

`app/build/outputs/apk/debug/app-debug.apk`

This repository does not include a Gradle wrapper JAR because it was not available in the environment and could not be downloaded. `scripts/build.sh` checks the required tools and invokes installed Gradle.

## Offline behavior and permissions

The manifest intentionally declares no `INTERNET` permission. The app accesses only files the user selects via the system document picker and exports to a location the user chooses. First-time dependency resolution for building the app requires network access, but the installed app's declared feature set has no network dependency.

## Libraries and licenses

- AndroidX / Jetpack Compose: Apache License 2.0.
- PDFBox-Android (`com.tom-roush:pdfbox-android:2.0.27.0`): Apache License 2.0; see the upstream project and artifact metadata for exact notices.
- Android platform APIs: governed by Android SDK terms.

The project does not bundle third-party font files. It uses Android's system sans-serif typeface for overlay text. Device font availability can vary. Verify any additional fonts and licenses before bundling them.

## Tests and verification

A small JVM unit test covers Unicode model retention and normalized overlay defaults. It does not prove visual Urdu/Arabic shaping, PDF export correctness, OCR, or device compatibility. Run tests and manually verify on an emulator/device before distributing.

## Privacy

The app contains no login, subscription, cloud upload, analytics, or Internet permission. PDF data is copied into app cache for processing; Android may remove cache files when needed. Export is user-directed through Android's document picker.
